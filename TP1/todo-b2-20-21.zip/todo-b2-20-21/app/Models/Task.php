<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    use HasFactory;

    public function board(){
        return $this->belongsTo(app\Models\Board);
    }

    public function category(){
        return $this->hasOne(app\Models\Category);
    }

    public function attachment(){
        return $this->hasMany(pp\Models\Attachment);
    }
}
